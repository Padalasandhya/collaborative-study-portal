# Microsoft-Engage

08th Nov - 28th Nov


VIDEO DEMO LINK - [here](https://youtu.be/7a9-Qk-Pc4I)

## Idea: 
Making a website for studying & notes sharing.

## Frameworks: 
Django, HTML, CSS, JavaScript, Sqlite

# Functionalities:
1. Notes
2. Homework
3. Youtube Search
4. Todos
5. Books
6. Dictionary
7. WikiPedia Search
8. Basic Conversion calculator

## NOTES


# Timeline:
| Date  | Milestone |
| ------------- | ------------- |
| 8th to 12th  | Brainstorming Ideas |
| 12th to 14th  | Buidling prototype for ideas |
| 14th  | Discussing ideas with mentor & finalizing |
| 15th | Start Coding |
| 15th to 22th  | Buiding basic app |
| 22nd | Reviewing to mentor |
| 22nd to 26th   | Improve/Add functionalities |
| 26th  | Documentation |
| 27th  | Deployment |
| 28th  | Submission |
